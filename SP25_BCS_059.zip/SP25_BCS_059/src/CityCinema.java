package sp25_bcs_059;
public class CityCinema {
    private String cityName;
    private Cinema[] cinemas;
    private int cinemaCount;

    public CityCinema(String cityName, int numCinemas) {
        this.cityName = cityName;
        cinemas = new Cinema[numCinemas];
        for (int i = 0; i < numCinemas; i++) {
            cinemas[i] = new Cinema("Cinema-" + (i + 1), 2);
        }
        cinemaCount = numCinemas;
    }

    public void displayCity() {
        System.out.println("\nCity: " + cityName);
        for (int i = 0; i < cinemaCount; i++) {
            cinemas[i].displayLayouts();
        }
    }

    public void bookSeat(int cinemaIndex, int screenIndex, String seatId) {
        if (cinemaIndex < 0 || cinemaIndex >= cinemaCount)
            System.out.println("Invalid cinema index!");
        else
            cinemas[cinemaIndex].bookSeat(screenIndex, seatId);
    }

    public void cancelSeat(int cinemaIndex, int screenIndex, String seatId) {
        if (cinemaIndex < 0 || cinemaIndex >= cinemaCount)
            System.out.println("Invalid cinema index!");
        else
            cinemas[cinemaIndex].cancelSeat(screenIndex, seatId);
    }
}
