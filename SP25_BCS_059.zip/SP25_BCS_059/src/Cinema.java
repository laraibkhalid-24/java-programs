package sp25_bcs_059;
public class Cinema {
    private String name;
    private Screen[] screens;
    private int screenCount;

    public Cinema(String name, int numScreens) {
        this.name = name;
        screens = new Screen[numScreens];
        for (int i = 0; i < numScreens; i++) {
            screens[i] = new Screen("Screen-" + (i + 1));
        }
        screenCount = numScreens;
    }

    public void displayLayouts() {
        System.out.println("\nCinema: " + name);
        for (int i = 0; i < screenCount; i++) {
            screens[i].displayLayout();
        }
    }

    public void bookSeat(int screenIndex, String seatId) {
        if (screenIndex < 0 || screenIndex >= screenCount)
            System.out.println("Invalid screen index!");
        else
            screens[screenIndex].bookSeat(seatId);
    }

    public void cancelSeat(int screenIndex, String seatId) {
        if (screenIndex < 0 || screenIndex >= screenCount)
            System.out.println("Invalid screen index!");
        else
            screens[screenIndex].cancelSeat(seatId);
    }

    public String getName() { return name; }
}

