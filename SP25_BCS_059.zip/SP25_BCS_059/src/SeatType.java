package sp25_bcs_059;
public enum SeatType {
    REGULAR, PREMIUM, VIP, RECLINER
}
