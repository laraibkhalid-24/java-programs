package sp25_bcs_059;
public class Screen {
    private String name;
    private Seat[][] seats;

    public Screen(String name) {
        this.name = name;
        int[] rowLengths = {10, 11, 12, 13, 14};
        seats = new Seat[rowLengths.length][];

        for (int i = 0; i < rowLengths.length; i++) {
            seats[i] = new Seat[rowLengths[i]];
            SeatType type;
            if (i < 2) type = SeatType.REGULAR;
            else if (i == 2) type = SeatType.PREMIUM;
            else if (i == 3) type = SeatType.VIP;
            else type = SeatType.RECLINER;

            for (int j = 0; j < rowLengths[i]; j++) {
                seats[i][j] = new Seat(i + 1, j + 1, type);
            }
        }
    }

    public Seat findSeatById(String id) {
        for (Seat[] row : seats) {
            for (Seat s : row) {
                if (s.getId().equals(id)) return s;
            }
        }
        return null;
    }

    public void bookSeat(String id) {
        Seat s = findSeatById(id);
        if (s != null) s.book();
        else System.out.println("Seat not found!");
    }

    public void cancelSeat(String id) {
        Seat s = findSeatById(id);
        if (s != null) s.cancel();
        else System.out.println("Seat not found!");
    }

    public void displayLayout() {
        System.out.println("\nLayout of " + name);
        for (Seat[] row : seats) {
            for (Seat s : row) {
                System.out.print(s.isAvailable() ? "O " : "X ");
            }
            System.out.println();
        }
    }

    public void displayDetails() {
        System.out.println("\nDetails for " + name);
        for (Seat[] row : seats) {
            for (Seat s : row) {
                System.out.println(s);
            }
        }
    }

    public String getName() { return name; }
}
