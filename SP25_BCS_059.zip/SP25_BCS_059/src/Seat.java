package sp25_bcs_059;
public class Seat {
    private String id;
    private SeatType type;
    private double price;
    private boolean isAvailable;

    public Seat(int row, int col, SeatType type) {
        this.id = row + "-" + String.format("%03d", col);
        this.type = type;
        this.isAvailable = true;

        switch (type) {
            case REGULAR: this.price = 500; break;
            case PREMIUM: this.price = 750; break;
            case VIP: this.price = 1000; break;
            case RECLINER: this.price = 1200; break;
        }
    }

    public boolean book() {
        if (!isAvailable) {
            System.out.println("Seat " + id + " is already booked!");
            return false;
        }
        isAvailable = false;
        System.out.println("Seat " + id + " booked successfully.");
        return true;
    }

    public boolean cancel() {
        if (isAvailable) {
            System.out.println("Seat " + id + " is not booked yet!");
            return false;
        }
        isAvailable = true;
        System.out.println("Booking cancelled for seat " + id);
        return true;
    }

    public boolean isAvailable() { return isAvailable; }
    public SeatType getType() { return type; }
    public double getPrice() { return price; }
    public String getId() { return id; }

    @Override
    public String toString() {
        return String.format("Seat %s | Type: %-9s | Price: %.2f PKR | Available: %s",
                id, type, price, isAvailable ? "Yes" : "No");
    }
}
