package sp25_bcs_059;
public class CinemaDemo {
    public static void main(String[] args) {
        CityCinema karachi = new CityCinema("Karachi", 2);
        CityCinema lahore = new CityCinema("Lahore", 2);
        CityCinema islamabad = new CityCinema("Islamabad", 1);

      
        karachi.displayCity();
        lahore.displayCity();
        islamabad.displayCity();

        System.out.println("\nBooking seat 3-007 in Karachi Cinema-1 Screen-1");
        karachi.bookSeat(0, 0, "3-007");
        karachi.bookSeat(0, 0, "3-007"); 
        karachi.cancelSeat(0, 0, "3-007");

     
        karachi.displayCity();
    }
}
