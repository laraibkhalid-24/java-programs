package sp25_bcs_059;
public class SeatDemo {
    public static void main(String[] args) {
        Seat s1 = new Seat(1, 1, SeatType.REGULAR);
        Seat s2 = new Seat(1, 2, SeatType.VIP);
        Seat s3 = new Seat(2, 5, SeatType.RECLINER);

        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);

        s1.book();
        s1.book(); 
        s1.cancel();
        System.out.println(s1);
    }
}
