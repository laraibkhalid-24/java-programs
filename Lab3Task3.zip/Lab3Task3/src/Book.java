public class Book{
	private String id;
	private String title;
	private String genre;
	private Person author;
	private Date publicationDate;
	
	private static int counter=1;
	
	public Book (){
		id=String.format("LB25-BK-%03d",counter++);
		this.title="Default";
		this.genre="Unknown";
		this.author=new Person("Unknown","Male","Unknown");
		this.publicationDate=new Date(20,11,2025);
	}
	
	public Book(String title,String genre,Person author,Date publicationDate){
		id=String.format("LB25-BK-%03d",counter++);
		this.title=title;
		this.genre=genre;
		this.author=author;
		this.publicationDate=publicationDate;
		
	}
	
	public Book(Book o){
		this.id=o.id;
		this.title=o.title;
		this.genre=o.genre;
		this.author=new Person(o.author);
		this.publicationDate=new Date(o.publicationDate);
	}
	public void setTitle(String title){
		this.title =title;
	}
	public String getTitle(){
		return title;
	}
	public void setGenre(String genre){
		this.genre =genre;
	}
	public String getGenre(){
		return genre;
	}
	public String getId(){
		return id;
	}
	public void setAuthor(Person author){
		this.author =author;
	}
	public Person getAuthor(){
		return author;
	}
	public void setPublicationDate(Date publicationDate){
		this.publicationDate =publicationDate;
	}
	public Date getPublicationDate(){
		return publicationDate;
	}
	@Override
	public boolean equals(Object o){
		Book b=(Book)o;
		return this.id.equals(b.id)&&
		       this.title.equals(b.title)&&
			   this.genre.equals(b.genre)&&
			   this.author.equals(b.author)&&
			   this.publicationDate.equals(b.publicationDate);
	}
	
	@Override
	public String toString(){
		return String.format("Book id is:%s%n Title is:%s%n Genre is:%s%n Details of author-->%s%n Publication data-->%s%n",id,title,genre,author,publicationDate);
		
	}
	
}