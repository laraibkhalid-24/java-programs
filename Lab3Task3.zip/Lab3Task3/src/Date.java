public class Date{
	private int day;
	private int month;
	private int year;
	
	public Date(int day,int month,int year){
		this.day=day;
		this.month=month;
		this.year=year;
	}
	public Date(Date o){
		this.day=o.day;
		this.month=o.month;
		this.year=o.year;
	}
	
	public void setDay(int day){
		this.day=day;
	}
	public int getDay(){
		return day;
	}
	public void setMonth(int month){
		this.month=month;
	}
	public int getMonth(){
		return month;
	}
	public void setYear(int day){
		this.year=year;
	}
	public int getYear(){
		return year;
	}
	@Override
	public boolean equals(Object o){
		Date d=(Date)o;
		return this.day==day&&
		       this.month==d.month&&
			   this.year==d.year;
			   		   
	}
	
	@Override
	public String toString(){
		return String.format("%02d-%02d-%04d",day,month,year);
}
    public boolean isBefore(Date o){
		if (this.year < o.year) return true;
		if (this.year == o.year && this.month < o.month) return true;
		if (this.year== o.year && this.month == o.year && this.day < o.day)return true;
		return false;
	}
}
