public class Person{
	private String name;
	private String gender;
	private String adress;
	
	public Person(String name,String gender,String adress)
	{
		this.name=name;
		this.gender=gender;
		this.adress=adress;
		
	}
	public Person(Person o)
	{
		this.name=o.name;
		this.gender=o.gender;
		this.adress=o.adress;
		
	}
	
	public void setName(String name){
		if (name !=null)
			this.name =name;
	}
	public String getName(){
		return name;
	}
	public void setGender(String gender){
		this.gender =gender;
	}
	public String getGender(){
		return gender;
	}
	public void setAdress(String adress){
		this.adress=adress;
	
	}
	public String getAdress(){
		return adress;
	}
	@Override 
	public boolean equals(Object o){
		Person p= (Person)o;
		return this.name.equals(p.name)&&
		       this.gender.equals(p.gender)&&
			   this.adress.equals(p.adress);
	}
	@Override
	public String toString(){
		return String.format("Name=%s , Gender=%s , Adress=%s ",name,gender,adress);
	}
	
}