public class LibraryTest{
	public static void main(String[]args){
		
		Book b1=new Book("Physics","Education",new Person("Laraib","Female","Lahore"),new Date(20,12,2000));
		Book b2=new Book("Chemistry","Experimentation",new Person("Alexander","Male","Russia"),new Date(20,12,1999));
		Book b3=new Book();
		Book b4=new Book(b1);
		System.out.println("------Details of Books------");
		System.out.println("  --Book 1 details--");
		System.out.println(b1);
		System.out.println("  --Book 2 details--");
		System.out.println(b2);
		System.out.println("  --Book 4 details--");
		System.out.println(b4);
		System.out.println("------Equality Check------");
		  if (b1.equals(b4)){
			System.out.println("are equal");
		}
		  if (b2.equals(b4)){
			  System.out.println("Are equal");
		  } else {
			  System.out.println("Are not equal");
		  }
		  
		  if (b1.getPublicationDate().isBefore(b2.getPublicationDate())){
			  System.out.println("Book 1 was published before book 2");
		  }else{
			  System.out.println("Book 1 was not published before book 2");
		  }
		
		
		
	
	}
}