public class RectangleTest{
    public static void main(String[] args){
      Rectangle rec=new Rectangle();
    double a= rec.rectangleArea();
    double b=rec.rectanglePerimeter();
   System.out.printf("Area of the rectangle is %f",a);
   System.out.printf("\nPerimeter of the rectangle is %f",b);
}
}
