class PrimitiveTypes{
    public static void main(String [] args){
        

       int i=20;  
       short s=200;
       byte b=20;
       long l =2345;
       double d=10.0;
       float f=20.98f;
       char c='l';
       boolean b1=true;
     System.out.printf("The value of integer is %d",i);
     
     System.out.printf("\nThe value of short is %d",s);
     
     System.out.printf("\nThe value of byte is %d",b);
     
     System.out.printf("\nThe value of long is %d",l);

     
     System.out.printf("\nThe value of double is %f",d);

     
     System.out.printf("\nThe value of float is %f",f);

     
     System.out.printf("\nThe value of character is %c",c);
     
     System.out.printf("\nThe value of boolean is %b",b1);










         
}
}




        