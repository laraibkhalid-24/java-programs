public class Rectangle{    
        
    double length = 23.98;
    double width =30.98;
   double rectangleArea(){
  double area;
area = length*width;
return area;
  }
  double rectanglePerimeter(){
double perimeter;
  perimeter =2*(length+width);
return perimeter;

}

}